-- AlterTable
ALTER TABLE "Gift" ADD COLUMN "messageMainProductId" TEXT;
ALTER TABLE "Gift" ADD COLUMN "recipeientMainProductId" TEXT;
ALTER TABLE "Gift" ADD COLUMN "wrapMainProductId" TEXT;
