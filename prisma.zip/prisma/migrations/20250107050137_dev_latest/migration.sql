-- AlterTable
ALTER TABLE "Gift" ADD COLUMN "giftReceiptCustomizationColor" TEXT;
ALTER TABLE "Gift" ADD COLUMN "giftReceiptCustomizationEmoji" TEXT;
ALTER TABLE "Gift" ADD COLUMN "giftReceiptCustomizationText" TEXT;
ALTER TABLE "Gift" ADD COLUMN "giftReceiptEmailCustomizationColor" TEXT;
ALTER TABLE "Gift" ADD COLUMN "giftReceiptEmailCustomizationEmoji" TEXT;
ALTER TABLE "Gift" ADD COLUMN "giftReceiptEmailCustomizationText" TEXT;
