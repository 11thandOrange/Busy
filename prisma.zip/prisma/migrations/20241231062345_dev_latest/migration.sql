-- AlterTable
ALTER TABLE "Gift" ADD COLUMN "updatedAt" DATETIME;
