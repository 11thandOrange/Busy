-- AlterTable
ALTER TABLE "GiftWrap" ADD COLUMN "productId" INTEGER;
