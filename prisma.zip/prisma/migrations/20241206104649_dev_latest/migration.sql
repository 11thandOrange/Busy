-- AlterTable
ALTER TABLE "Cart_notice" ADD COLUMN "hideTheFireIcon" TEXT;
